import { renderApp } from './components/layout.js';
import './styles/main.css';

const app = document.querySelector('#app');

if (!app) {
  throw new Error('App root #app was not found.');
}

app.innerHTML = renderApp();

const form = document.querySelector('.contact-form');
if (form) {
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    window.alert('Hook this form up to Formspree, Netlify Forms, WhatsApp, or your backend.');
  });
}
