import {
  navLinks,
  stats,
  categories,
  products,
  craftMaterials,
  shippingDestinations,
  contactDetails,
} from '../data/site.js';

const navMarkup = navLinks
  .map((link) => `<li><a href="${link.href}">${link.label}</a></li>`)
  .join('');

const statsMarkup = stats
  .map(
    (item) => `
      <div class="stat-card">
        <strong>${item.value}</strong>
        <span>${item.label}</span>
      </div>
    `,
  )
  .join('');

const categoryMarkup = categories
  .map(
    (item) => `
      <article class="category-card">
        <span class="category-card__icon">${item.icon}</span>
        <h3>${item.name}</h3>
        <p>${item.count}</p>
      </article>
    `,
  )
  .join('');

const productsMarkup = products
  .map(
    (product, index) => `
      <article class="product-card">
        <div class="product-card__media product-card__media--${(index % 4) + 1}">
          <span class="pill">${product.badge}</span>
        </div>
        <div class="product-card__body">
          <p class="eyebrow">${product.category}</p>
          <h3>${product.name}</h3>
          <p>${product.description}</p>
          <div class="product-card__footer">
            <strong>${product.price}</strong>
            <a href="#contact">Enquire</a>
          </div>
        </div>
      </article>
    `,
  )
  .join('');

const materialMarkup = craftMaterials
  .map((item) => `<li class="chip">${item}</li>`)
  .join('');

const shippingMarkup = shippingDestinations
  .map((item) => `<li class="shipping-grid__item">${item}</li>`)
  .join('');

const contactMarkup = contactDetails.map((item) => `<li>${item}</li>`).join('');

export function renderApp() {
  return `
    <div class="site-shell">
      <header class="site-header">
        <div class="container site-header__inner">
          <a class="brand" href="#top">
            <span class="brand__mark">JC</span>
            <span>
              <strong>Juju Couture</strong>
              <small>Handcrafted in Eswatini</small>
            </span>
          </a>
          <nav class="desktop-nav" aria-label="Primary">
            <ul>${navMarkup}</ul>
          </nav>
          <a class="button button--primary" href="#contact">Order Now</a>
        </div>
      </header>

      <main id="top">
        <section class="hero">
          <div class="container hero__grid">
            <div class="hero__content">
              <p class="eyebrow">Handcrafted in Eswatini · Ships Worldwide</p>
              <h1>Wear Africa. Own the world.</h1>
              <p class="hero__body">
                Juju Couture creates premium handcrafted bags and accessories inspired by African texture,
                color, and identity. Each piece is designed to feel editorial, collectible, and unmistakably original.
              </p>
              <div class="hero__actions">
                <a class="button button--primary" href="#collections">Shop the Collection</a>
                <a class="button button--secondary" href="#craft">Our Story</a>
              </div>
              <div class="stats-grid">${statsMarkup}</div>
            </div>
            <div class="hero__visual" aria-hidden="true">
              <div class="hero__visual-card">
                <span>Luxury craft</span>
                <strong>African accessories with global appeal</strong>
              </div>
            </div>
          </div>
        </section>

        <section class="section section--soft" id="collections">
          <div class="container">
            <div class="section-heading">
              <p class="eyebrow">Collections</p>
              <h2>Signature categories</h2>
            </div>
            <div class="category-grid">${categoryMarkup}</div>
          </div>
        </section>

        <section class="section">
          <div class="container">
            <div class="section-heading section-heading--split">
              <div>
                <p class="eyebrow">Featured Products</p>
                <h2>Built like a modern luxury brand</h2>
              </div>
              <p class="section-copy">
                This structure is ready for real product data, CMS content, analytics, forms, and deployment.
              </p>
            </div>
            <div class="product-grid">${productsMarkup}</div>
          </div>
        </section>

        <section class="section section--accent" id="craft">
          <div class="container craft-grid">
            <div>
              <p class="eyebrow">Materials & Craft</p>
              <h2>Made with soul</h2>
              <p class="section-copy">
                Juju Couture combines traditional African materials with modern silhouettes. The result is a brand story
                that feels authentic, premium, and export-ready.
              </p>
              <p class="section-copy">
                The original prototype already positioned the brand around handcrafted African bags, global shipping,
                and materials like ankara, bamboo, kente, cowhide, denim, crochet yarn, and straw. This refactor keeps
                that direction while making the codebase maintainable. 
              </p>
              <ul class="chip-list">${materialMarkup}</ul>
            </div>
            <div class="craft-panel" aria-hidden="true"></div>
          </div>
        </section>

        <section class="section" id="shipping">
          <div class="container shipping-panel">
            <div class="section-heading section-heading--center">
              <p class="eyebrow">International Delivery</p>
              <h2>We ship to your country</h2>
              <p class="section-copy section-copy--center">
                The site is set up to support direct enquiries, shipping quotes, and a future checkout flow.
              </p>
            </div>
            <ul class="shipping-grid">${shippingMarkup}</ul>
          </div>
        </section>

        <section class="section section--soft" id="contact">
          <div class="container contact-grid">
            <div>
              <p class="eyebrow">Order or Enquire</p>
              <h2>Let’s build the buyer journey properly</h2>
              <p class="section-copy">
                This contact section is ready to connect to Formspree, Netlify Forms, a custom backend, or WhatsApp.
              </p>
              <ul class="contact-list">${contactMarkup}</ul>
            </div>
            <form class="contact-form">
              <label>
                <span>Name</span>
                <input type="text" name="name" placeholder="Your name" />
              </label>
              <label>
                <span>Email</span>
                <input type="email" name="email" placeholder="you@example.com" />
              </label>
              <label>
                <span>Product Interest</span>
                <select name="interest">
                  <option>Bags</option>
                  <option>Clutches</option>
                  <option>Backpacks</option>
                  <option>Accessories</option>
                  <option>Custom Order</option>
                </select>
              </label>
              <label>
                <span>Message</span>
                <textarea name="message" rows="5" placeholder="Tell us what you want to order"></textarea>
              </label>
              <button class="button button--primary" type="submit">Send Enquiry</button>
            </form>
          </div>
        </section>
      </main>

      <footer class="site-footer">
        <div class="container site-footer__inner">
          <div>
            <strong>Juju Couture</strong>
            <p>Editorial African craftsmanship, designed for a global market.</p>
          </div>
          <p>© 2026 Juju Couture. All rights reserved.</p>
        </div>
      </footer>
    </div>
  `;
}
