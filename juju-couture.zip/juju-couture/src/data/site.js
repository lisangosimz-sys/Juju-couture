export const navLinks = [
  { label: 'Collections', href: '#collections' },
  { label: 'Craft', href: '#craft' },
  { label: 'Shipping', href: '#shipping' },
  { label: 'Contact', href: '#contact' },
];

export const stats = [
  { value: '100%', label: 'Handmade' },
  { value: 'Global', label: 'Shipping Reach' },
  { value: '20+', label: 'Signature Designs' },
];

export const categories = [
  { name: 'Bags', count: '12 styles', icon: '👜' },
  { name: 'Clutches', count: '6 styles', icon: '✨' },
  { name: 'Backpacks', count: '4 styles', icon: '🎒' },
  { name: 'Hats', count: '5 styles', icon: '👒' },
  { name: 'Wallets', count: '8 styles', icon: '💼' },
];

export const products = [
  {
    name: 'Ndlovukati Tote',
    category: 'Statement Bag',
    price: 'From E1,250',
    description: 'Structured tote with bold African textile panels and a premium carry silhouette.',
    badge: 'Best Seller',
  },
  {
    name: 'Mbabane Clutch',
    category: 'Evening Piece',
    price: 'From E680',
    description: 'Elegant hand-finished clutch designed for occasions, gifting, and standout styling.',
    badge: 'New',
  },
  {
    name: 'Lobamba Backpack',
    category: 'Travel Edit',
    price: 'From E1,480',
    description: 'A functional backpack with artisan details for modern travel and daily wear.',
    badge: 'Limited',
  },
  {
    name: 'Ezulwini Wallet',
    category: 'Accessories',
    price: 'From E420',
    description: 'Compact wallet combining handcrafted texture, utility, and everyday luxury.',
    badge: 'Popular',
  },
];

export const craftMaterials = [
  'Ankara',
  'Bamboo',
  'Kente',
  'Cowhide',
  'Crochet',
  'Denim',
  'Straw',
  'Beads',
];

export const shippingDestinations = [
  'Eswatini',
  'South Africa',
  'United Kingdom',
  'United States',
  'Germany',
  'France',
  'Australia',
  'Japan',
  'UAE',
  'India',
  'Brazil',
  'More',
];

export const contactDetails = [
  'Eswatini (Swaziland), Southern Africa',
  'WhatsApp orders welcome',
  'International shipping available worldwide',
  'Response time: within 24 hours',
  'Payments via EFT, mobile money, and secure online channels',
];
